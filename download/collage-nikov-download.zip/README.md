# collage-nikov

The purpose of this work is to encode information in raw materials found in the environment, first the digital environment then the physical environment(trash).  

The first version I'm making available is for the mac as an .app file.  

HOW TO USE:

1. name a image file input.jpg, which obviously must be in jpg format. A high resolution file is good if you can.  It has to be named EXACTLY "input.jpg", no variations will work. This download should have an input file with that name as an example to start with
2. put the file in the same directory as the app, which can be anywhere, it does not need to be in your special applications directory or whatever.
3. run the app
4. move mouse around and see the cursor and how it blows up pixels from wherever it is and shows what's in the box.  Find a letter or shape you want to represent a given letter on your keyboard, hold down shift and hit that key.  This should grab that letter to your letter list in the upper left of the image.
5. move the mouse to where you want to type out copied letters and images, and click the mouse to start a sequence of text there.  type WITHOUT shift or caps lock on, using only lowercase, no numbers, and it should come out copied from the letter table. 
6. zoom in or out if you need to using "-" for decrease size of cursor and "=" for increase size of cursor, but only do this once at the beginning or the scales will get very broken--this is a bug that I can fix but have not fixed.  
7. when you like what you see hit RETURN/ENTER on your keyboard to save, and it should generate an output file called output.jpg, which you can now view, post, or whatever, in addition to changing the name to input.jpg and going back and editing it more or passing it along to the NEXT person to edit.  


A goal of this very primitive version is to both make amusing memes and hopefully to make them much more of a shared, flowing thing, where a constant feed of digital trash is processed by a whole circle of creators, because this is the backbone on which the value circle of post capitalist economics will be based, with Tales and Lore as outlined in my manifesto.  

Contained in this download folder as of Nov 6, 2016:

collage-nikov.app
input.jpg
collage-nikov.pde

All this stuff lives at github at https://github.com/LafeLabs/collage-nikov

Intellectual "property" notice:

none claimed or recognized, nor any other law by the number worshippers. no laws, no money, no mining, only trash and geometry